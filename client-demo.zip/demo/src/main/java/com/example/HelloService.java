package com.example;

public interface HelloService {

    String sayHello(String name);

}